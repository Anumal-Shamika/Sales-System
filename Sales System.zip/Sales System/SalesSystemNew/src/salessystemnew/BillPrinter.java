
package salessystemnew;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import static java.awt.print.Printable.NO_SUCH_PAGE;
import static java.awt.print.Printable.PAGE_EXISTS;
import java.awt.print.PrinterException;
import java.util.ArrayList;
import javax.swing.ImageIcon;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Ravindra
 */
public class BillPrinter implements Printable  {
    private Image logo;
    //private String[] billDetails;
    private ArrayList<String> billDetails;

    public BillPrinter(String logoPath, ArrayList<String> billDetails) {
        this.logo = new ImageIcon(logoPath).getImage();
        this.billDetails = billDetails;
    }

    @Override
    public int print(Graphics g, PageFormat pf, int page) throws PrinterException {
        if (page > 0) { // We only print one page
            return NO_SUCH_PAGE;
        }

        Graphics2D g2d = (Graphics2D) g;
        g2d.translate(pf.getImageableX(), pf.getImageableY());

        // Draw the logo
        g.drawImage(logo, 200, 20, null);

        // Draw the bill details
        g.setFont(new Font("Serif", Font.PLAIN, 16));
        int y = 150; // Starting Y position for text
        int tabSpacing = 100; // X position for tabbed text
        for (String line : billDetails) {
            String[] parts = line.split("\t");
            int x = 50;
            for (String part : parts) {
                g.drawString(part, x, y);
                x += tabSpacing; // Move to the next tab position
            }
            
            y += 25; // Line spacing
        }

        return PAGE_EXISTS;
    }
}
